#pragma once
#include <mpir.h>

int isPrime(size_t n);
size_t nextPrime(size_t op);