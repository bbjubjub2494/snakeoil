#pragma once
char* PSP(char* buffer, size_t startP, size_t jumpP);
void W_PSP(wchar_t* buffer, size_t startP, size_t jumpP);
/* Decryption item removed */
/* Decryption item removed */
void validate_jump_point(size_t* jp);
void validate_start_point(size_t* sp);

/* Decryption item removed */